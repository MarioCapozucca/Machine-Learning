# imports
import pandas as pd
import seaborn as sea
import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import LinearRegression
import LR_theory_complete as lrc
import LR_theory_complete as lrt
# load dataset
df = pd.read_csv('datasets/auto-MPG/auto-MPG_tr.csv')

# handle null values
print(df.isnull().any())
df = df.fillna(method='ffill')

# look at the dataset
print(df.info())
print(df.describe())
print(df.head())
print(df.columns)
# MPG miglia per galloni
df['Molti MPG'] = (df['MPG'] > 21).astype('int')
df['HP_bin'] = (pd.cut(df['HP'], 10))
plt.figure(1)
sea.countplot(x='CYL', hue='Molti MPG', data=df)
plt.figure(2)
sea.countplot(x='HP_bin', hue='Molti MPG', data=df)
plt.show()

# choose features
features = list(set(df.columns) - set(['NAME', 'MPG', 'Molti MPG', 'HP_bin', 'YR']))
X_df = df[features]
corr_matrix = X_df.corr()
sea.heatmap(corr_matrix)
plt.show()

# prepare design matrix (containing features) and the target vector (the MPG values)
X = lrt.standardize(X_df)
y = df['MPG']
y = y/10
# split the dataset (80% training, 20% test)
split =0.8
tr_size = np.int(X_df.shape[0] * split)
y_tr = y[0:tr_size]
y_ts = y[tr_size:]

X_ts = X[tr_size:]
X_tr = X[0:tr_size]

# set, fit and predict
lr =LinearRegression()
lr.fit(X_tr, y_tr)
y_te_hat = lr.predict(X_ts)
# look at the results
#mse
print('Error on train (MSE) = ', lrc.MSE(y_tr, lr.predict(X_tr)))
print('Error on test (MSE) = ', lrc.MSE(y_ts, y_te_hat))
print('\n')
#mae
print('Error on train (MAE) = ', lrc.MAE(y_tr, lr.predict(X_tr)))
print('Error on test (MAE) = ', lrc.MAE(y_ts, y_te_hat))
print('\n')

#Rquadro
print('R2 on train = ', lrc.R2(y_tr, lr.predict(X_tr)))
print('R2 on test = ', lrc.R2(y_ts, y_te_hat))
print('\n')