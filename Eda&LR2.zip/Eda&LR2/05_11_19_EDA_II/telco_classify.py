import warnings
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, f1_score, \
    precision_recall_curve, roc_curve, confusion_matrix
from sklearn.preprocessing import StandardScaler #fa la standardizzazione
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression


warnings.simplefilter(action='ignore', category=FutureWarning)

output_dictionary = {'Yes': 0, 'No': 1}
#noi sappiamo che la nostra variabile targhet è una variabile target di tipo yes o no

def distplot(feature, frame, color='g'): #distribution plot, come si distribuiscono le feature nei samples
    plt.figure(figsize=(8, 3))
    plt.title("Distribution for {}".format(feature))
    ax = sns.distplot(frame[feature], color=color)


########################################################################################################################
#########                                               MODEL(S)                                               #########
########################################################################################################################
models_name = []

# K-Nearest Neighbors
knn_model = KNeighborsClassifier(n_neighbors=2)
models_name.append('K-Nearest Neighbors')

# TODO: instantiate other suitable classifiers
#Logistic Regression
lr = LogisticRegression()

########################################################################################################################
#########                                               TRAINING                                               #########
########################################################################################################################
df = pd.read_csv("telco/WA_Fn-UseC_-Telco-Customer-Churn__train.csv")
df.head(3)
df.columns

# select features and target
y_train = df['Churn'].replace(output_dictionary)
X = df.drop(columns='Churn')

# Impute missing values
X['TotalCharges'] = X['TotalCharges'].replace(" ", 0).astype('float32')
X.drop(['customerID'], axis=1, inplace=True)

# Preprocess categorical features
categorical_cols = [c for c in X.columns if X[c].dtype == 'object' or c == 'SeniorCitizen']
X_categorical = X[categorical_cols].copy()
for col in categorical_cols:
    if X_categorical[col].nunique() == 2:
        X_categorical[col], _ = pd.factorize(X_categorical[col])
    else:
        X_categorical = pd.get_dummies(X_categorical, columns=[col])
X_categorical.head(3)

# Preprocess numerical features
numerical_cols = ['tenure', 'MonthlyCharges', 'TotalCharges']
X[numerical_cols].describe()
for feat in numerical_cols:
    distplot(feat, X)
scaler = StandardScaler().fit(X[numerical_cols].astype('float64')) # funzione che implementa la standarizzazione
X_std = pd.DataFrame(scaler.transform(X[numerical_cols].astype('float64')), columns=numerical_cols)
for feat in numerical_cols:
    distplot(feat, X_std, color='gray')

# Redefine features
X_train = pd.concat([X_categorical, X_std], axis=1, sort=False)

########################################################################################################################
# Train model(s)
knn_model.fit(X_train, y_train) #addestramento

# TODO: train other suitable classifiers
lr.fit(X_train, y_train)


########################################################################################################################
#########                                                 TEST                                                 #########
########################################################################################################################
df = pd.read_csv("telco/WA_Fn-UseC_-Telco-Customer-Churn__test.csv")

# select features and target
y_test = df['Churn'].replace(output_dictionary)
X = df.drop(columns='Churn')

# Impute missing values
X['TotalCharges'] = X['TotalCharges'].replace(" ", 0).astype('float32')
X.drop(['customerID'], axis=1, inplace=True)

# Preprocess categorical features
categorical_cols = [c for c in X.columns if X[c].dtype == 'object' or c == 'SeniorCitizen']
X_categorical = X[categorical_cols].copy()
for col in categorical_cols:
    if X_categorical[col].nunique() == 2:
        X_categorical[col], _ = pd.factorize(X_categorical[col])
    else:
        X_categorical = pd.get_dummies(X_categorical, columns=[col])
X_categorical.head(3)

# Preprocess numerical features
numerical_cols = ['tenure', 'MonthlyCharges', 'TotalCharges']
X_std = pd.DataFrame(scaler.transform(X[numerical_cols].astype('float64')), columns=numerical_cols)

# Redefine features
X_test = pd.concat([X_categorical, X_std], axis=1, sort=False)

########################################################################################################################
y_predicted = []

# Test model(s)
y_pred_knn_model = knn_model.predict(X_test)
y_predicted.append(y_pred_knn_model)

# TODO: test other suitable classifiers

y_predi_by_lr = lr.predict(X_test)
y_predicted.append(y_predi_by_lr)

########################################################################################################################
#########                                              EVALUATION                                              #########
########################################################################################################################
for i in range(len(models_name)):
    print('/-------------------------------------------------------------------------------------------------------- /')
    print('RESULTS OF THE %s CLASSIFIER' % models_name[i])
    print('/-------------------------------------------------------------------------------------------------------- /')
    print('Accuracy is ', accuracy_score(y_test, y_predicted[i]))
    print('Precision is ', precision_score(y_test, y_predicted[i]))
    print('Recall is ', recall_score(y_test, y_predicted[i]))
    print('F1-Score is ', f1_score(y_test, y_predicted[i]))
    print('AUC is ', roc_auc_score(y_test, y_predicted[i]))

    fpr, tpr, _ = roc_curve(y_test, y_predicted[i])
    plt.figure('ROC')
    plt.title('ROC curve')
    plt.plot(fpr, tpr, label=models_name[i], linewidth=4)
    plt.plot([0, 1], [0, 1], 'k--')
    plt.ylabel('TPR')
    plt.xlabel('FPR')
    plt.legend(loc='lower right')
    plt.xlim([0, 1])
    plt.ylim([0, 1])

    precision, recall, _ = precision_recall_curve(y_test, y_predicted[i])
    plt.figure('PR')
    plt.title('P-R curve')
    plt.plot(recall, precision, label=models_name[i], linewidth=4)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.legend(loc='lower left')
    plt.ylim([0.0, 1.0])
    plt.xlim([0.0, 1.0])
    rest= confusion_matrix(y_test, y_pultedi_by_lr)
    good = rest[0,0] + rest[0,1]
    bad = falsep + falsen
    if(good > bad):
        print("linear regression makes world better")

plt.show()
