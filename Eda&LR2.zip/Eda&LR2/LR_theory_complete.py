import numpy as np
from time import time
from matplotlib import pyplot as plt


# -----------------------------------------------------
# Hypothesis function
# -----------------------------------------------------
def hyp(X, theta):
    '''
    :param X: Design matrix
    :param theta: Linear regression weights
    :return: the value of the hypothesis function for each row of X
    '''
    h = np.dot(X, theta)
    return h


# -----------------------------------------------------
# Cost function
# -----------------------------------------------------
def cost(X, y, theta):
    '''
    :param y: target values
    :param X: Design matrix
    :param theta: Linear regression weights
    :return: The cost function for the given input data
    '''
    h = hyp(X, theta)
    cost = np.dot((h - y).T, h - y) / (2 * h.shape[0])
    return cost


# -----------------------------------------------------
# Linear regression solver - gradient descent
# -----------------------------------------------------
def linear_regression_fit_GD(X, y, alpha, eps=0.0001):
    '''
    :param y: target values
    :param X: Design matrix
    :param alpha: learning rate
    :param eps: stopping threshold
    :return: The updated regression weights
    '''
    max_iter = 10000
    n, d = X.shape
    theta = np.random.randn(d)
    Jold = np.inf
    Jnew = cost(X, y, theta)
    iter = 0
    while np.abs(Jnew - Jold) >= eps and iter < max_iter:
        print("iter ", iter, "-> J: ", Jnew)
        iter += 1
        J_grad = 1 / n * np.dot((hyp(X, theta) - y), X)
        theta -= alpha * J_grad
        Jold = Jnew
        Jnew = cost(X, y, theta)
    print("Optimization stopped, num iters = ", iter)
    return theta


# -----------------------------------------------------
# Linear regression solver - LMS solution
# -----------------------------------------------------
def linear_regression_fit_NE(X, y):
    '''
    :param y: target values
    :param X: Design matrix
    :return: Linear regression weights
    '''
    theta_hat = np.dot(np.linalg.inv(np.dot(X.T, X)), np.dot(X.T, y))
    return theta_hat


# -----------------------------------------------------
# Standardization
# -----------------------------------------------------
def standardize(X):
    return (X - np.mean(X, axis=0)) / np.std(X, axis=0)


# -----------------------------------------------------
# Min-Max Scaling
# -----------------------------------------------------
def min_max_scale(X):
    return (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))


# -----------------------------------------------------
# Mean Normalization
# -----------------------------------------------------
def mean_normalize(X):
    return (X - np.mean(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))


# -----------------------------------------------------
# Mean Squared Error
# -----------------------------------------------------
def MSE(y_true, y_pred):
    n = len(y_true)
    return RSS(y_true, y_pred)/n


# -----------------------------------------------------
# Mean Absolute Error
# -----------------------------------------------------
def MAE(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred)))


# -----------------------------------------------------
# Residual Sum of Squares
# -----------------------------------------------------
def RSS(y_true, y_pred):
    return np.sum((y_true - y_pred) ** 2)


# -----------------------------------------------------
# Residual Standard Error
# -----------------------------------------------------
def RSE(y_true, y_pred, X):
    n, d = X.shape
    return np.sqrt(1 / (n - d - 1) * RSS(y_true, y_pred))


# -----------------------------------------------------
# Root Mean Square Error
# -----------------------------------------------------
def RMSE(y_true, y_pred):
    return np.sqrt(MSE(y_true, y_pred))


# -----------------------------------------------------
# R2 - Statistics
# -----------------------------------------------------
def R2(y_true, y_pred):
    TSS = np.sum((y_true - np.mean(y_true))**2)
    return 1 - RSS(y_true, y_pred)/TSS


def R2_adj(y_true, y_pred, X):
    '''
    :param y_true: target values
    :param y_pred: predicted y
    :param X: Design matrix
    :return: adjusted R2
    '''
    n, d = X.shape
    return 1 - (1-R2(y_true, y_pred))*(n - 1)/(n - d -1)

'''
Compare the NE and GD solutions using time() to measure the processing time. 
Try different learning rate values and normalization strategies and compare their processing time.
Evaluate the performance on the training set.
'''
# -----------------------------------------------------
# Hands On
# -----------------------------------------------------
if __name__ == "__main__":
    features_filename = 'LR_lab/datasets/features.dat'
    targets_filename = 'LR_lab/datasets/targets.dat'
    X = np.loadtxt(features_filename)
    y = np.loadtxt(targets_filename)
    ### A tiny bit of EDA_lab
    # print(X)
    # print(y)

    plt.figure(r'$x_1$ vs y')
    plt.scatter(X[:, 0], y)
    plt.figure(r'$x_2$ vs y')
    plt.scatter(X[:, 1], y)
    plt.show()
    ###  For Univariate LR, uncomment:
    # X = np.array([X[:, 0]]).T

    ### Normalization
    X = min_max_scale(X)

    ### Intercept term
    x_0 = np.ones((len(X), 1))
    X2 = np.append(x_0, X, axis=1)

    ### Compute theta with Gradient Descent and Normal Equation
    start_NE = time()
    theta_NE = linear_regression_fit_NE(X2, y)
    stop_NE = time()
    start_GD = time()
    theta_GD = linear_regression_fit_GD(X2, y, alpha=1e-7)
    stop_GD = time()
    print("theta from Normal Equation: ", theta_NE, " in ", (stop_NE - start_NE) * 1000, ' ms')
    print("theta from Gradient Descent: ", theta_GD, " in ", (stop_GD - start_GD) * 1000, ' ms')

    ### Predict using the theta from Gradient Descent and Normal Equation
    y_hat_NE = hyp(X2, theta_NE)
    y_hat_GD = hyp(X2, theta_GD)

    plt.figure('Hypotheses')
    plt.title('Hypotheses')
    plt.scatter(X[:, 0], y)
    plt.plot(X[:, 0], y_hat_NE, 'r', label='NE')
    plt.plot(X[:, 0], y_hat_GD, 'g', label='GD')
    plt.legend()
    plt.show()

    ###  Compute performance
    print("Performance of Normal Equation: ")
    print("RSS = ", RSS(y, y_hat_NE))
    print("RSE = ", RSE(y, y_hat_NE, X2))
    print("MSE = ", MSE(y, y_hat_NE))
    print("MAE = ", MAE(y, y_hat_NE))
    print("RMSE = ", RMSE(y, y_hat_NE))
    print("R2 = ", R2(y, y_hat_NE))
    print("R2_adj = ", R2_adj(y, y_hat_NE, X2))
    print("Performance of Gradient Descent: ")
    print("RSS = ", RSS(y, y_hat_GD))
    print("RSE = ", RSE(y, y_hat_GD, X))
    print("MSE = ", MSE(y, y_hat_GD))
    print("MAE = ", MAE(y, y_hat_GD))
    print("RMSE = ", RMSE(y, y_hat_GD))
    print("R2 = ", R2(y, y_hat_GD))
    print("R2_adj = ", R2_adj(y, y_hat_GD, X2))

    plt.figure('Predictions')
    plt.title('Predictions')
    plt.plot(y_hat_GD, label=r'$\hat{y}_{GD}$')
    plt.plot(y_hat_NE, label=r'$\hat{y}_{NE}$')
    plt.plot(y, label='y')
    plt.legend()
    plt.show()


