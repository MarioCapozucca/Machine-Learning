import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('datasets/telecom/telecom_churn.csv')
# df sta per dataframe

print(df.head()) # restituisce le prime 5 righe
print(df.shape) #lunghezza
print(df.columns)
print(df.info())

df['Churn'] = df['Churn'].astype('int64')
df.describe()
df.describe(include=['object', 'bool'])
df['Churn'].value_counts()
df['Churn'].value_counts(normalize=True)

df.sort_values(by='Total day charge', ascending=False).head()
df.sort_values(by=['Churn', 'Total day charge'], ascending=[True, False]).head()

print(df['Churn'].mean())
print(df[df['Churn'] == 1].mean())
print(df[df['Churn'] == 1]['Total day minutes'].mean())
print(df[(df['Churn'] == 0) & (df['International plan'] == 'No')]['Total intl minutes'].max())

print(df.loc[0:5, 'State':'Area code'])

print(df[-1:])

print(df[df['State'].apply(lambda state: state[0] == 'W')].head())

d = {'No': False, 'Yes': True} # crea un vocabolario
df['International plan'] = df['International plan'].map(d)
print(df.head())
df = df.replace({'Voice mail plan': d})
print(df.head())

columns_to_show = ['Total day minutes', 'Total eve minutes', 'Total night minutes']
print(df.groupby(['Churn'])[columns_to_show].describe(percentiles=[]))
columns_to_show = ['Total day minutes', 'Total eve minutes', 'Total night minutes']

print(df.groupby(['Churn'])[columns_to_show].agg([np.mean, np.std, np.min, np.max]))

print(pd.crosstab(df['Churn'], df['International plan']))
print(pd.crosstab(df['Churn'], df['Voice mail plan'], normalize=True))

# print(df.pivot_table(['Total day calls', 'Total eve calls', 'Total night calls'], ['Area code'], aggfunc='mean'))

total_calls = df['Total day calls'] + df['Total eve calls'] + df['Total night calls'] + df['Total intl calls']
df.insert(loc=len(df.columns), column='Total calls', value=total_calls)
# loc parameter is the number of columns after which to insert the Series object
# we set it to len(df.columns) to paste it at the very end of the dataframe
print(df.head())
df['Total charge'] = df['Total day charge'] + df['Total eve charge'] + df['Total night charge'] + df['Total intl charge']
print(df.head())
# get rid of just created columns
df.drop(['Total charge', 'Total calls'], axis=1, inplace=True) # inplace, ovvero modifica il file direttamente su quello che sta utilizzando.
# and here’s how you can delete rows
df.drop([1, 2]).head()

# sns as seaborn


print(pd.crosstab(df['Churn'], df['International plan'], margins=True))
sns.countplot(x='International plan', hue='Churn', data=df)

print(pd.crosstab(df['Churn'], df['Customer service calls'], margins=True))
sns.countplot(x='Customer service calls', hue='Churn', data=df)

df['Many_service_calls'] = (df['Customer service calls'] > 3).astype('int')
print(pd.crosstab(df['Many_service_calls'], df['Churn'], margins=True))
sns.countplot(x='Many_service_calls', hue='Churn', data=df)
pd.crosstab(df['Many_service_calls'] & df['International plan'], df['Churn'])

plt.show()
