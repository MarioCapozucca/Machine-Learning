import numpy as np
import pandas as pd
import seaborn as sns
import ast, json

from datetime import datetime
import matplotlib.pyplot as plt

auto_df = pd.read_csv('EDA_lab/datasets/auto-MPG/auto-MPG_tr.csv')
