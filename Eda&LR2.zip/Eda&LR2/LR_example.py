# imports
import numpy as np
import LR_theory_complete as lrt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import LR_theory_complete as lrc
from sklearn.model_selection import train_test_split
# Load housing dataset
feature_filename = 'Datasets/portland/features.dat'
target_filename = 'Datasets/portland/targets.dat'
x = np.loadtxt(feature_filename)
y = np.loadtxt(target_filename)

# normalize features
Xn = lrt.standardize(x)
y = y/1000
# add intercept
np.hstack([np.ones((Xn.shape[0],1 )), Xn])
# divide train and test sets
split =0.8
tr_size = np.int(Xn.shape[0] * split)
Xn_tr = Xn[0:tr_size]
y_tr = y[0:tr_size]
Xn_te = Xn[tr_size:]
y_ts = y[tr_size:]
# Xn_tr, Xn_te, y_tr, y_ts, = train_test_split(Xn, y, test_size=1-split, random_state=0 )
# instantiate Linear Regression algorithm
lr =LinearRegression()

# train regressor
lr.fit(Xn_tr, y_tr)
# test regressor
y_te_hat = lr.predict(Xn_te)
# print results
print('Error on train (MSE) = ', mean_squared_error(y_tr, lr.predict(Xn_tr)) )
print('Error on test (MSE) = ', mean_squared_error(y_ts, y_te_hat) )
print('\n')

print('Error on train (MSE) = ', mean_absolute_error(y_tr, lr.predict(Xn_tr)) )
print('Error on train (MSE) = ', mean_absolute_error(y_ts, y_te_hat) )
print('\n')

print('R2 on train = ', r2_score(y_tr, lr.predict(Xn_tr)))
print('R2 on test = ', r2_score(y_ts, y_te_hat))
print('\n')

# TODO: USE THE METRIC FUNCTIONS YOU IMPLEMENTED LAST TIME TO DEEPEN THE PERFORMANCE ANALYSIS
#mse
print('Error on train (MSE) = ', lrc.MSE(y_tr, lr.predict(Xn_tr)))
print('Error on test (MSE) = ', lrc.MSE(y_ts, y_te_hat))
print('\n')
#mae
print('Error on train (MAE) = ', lrc.MAE(y_tr, lr.predict(Xn_tr)))
print('Error on test (MAE) = ', lrc.MAE(y_ts, y_te_hat))
print('\n')

#Rquadro
print('R2 on train = ', lrc.R2(y_tr, lr.predict(Xn_tr)))
print('R2 on test = ', lrc.R2(y_ts, y_te_hat))
print('\n')


