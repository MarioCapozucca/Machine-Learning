# imports

# load and look at the dataset

# prepare design matrix and target vector

# split the dataset

# choose model

# fit and look at the model

# predict

# look at the results


